import React from 'react';
import { motion } from 'framer-motion';
import storyimage from '../assets/webimage/ourstory.jpg';
import storyimagetwo from '../assets/webimage/chocolate.png';


const sectionVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: "easeOut",
      when: "beforeChildren",
      staggerChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const OurStoryPage = () => {
  return (
    <motion.div
      className="bg-gradient-to-br from-[#A0522D] to-[#5A2E0A] py-16 px-6"
      variants={sectionVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="container mx-auto max-w-4xl">
        <motion.h1
          className="text-5xl md:text-6xl font-luckiest-guy text-[#ffffff] text-center mb-6 md:mb-8 drop-shadow-md"
          variants={itemVariants}
        >
          Our Jaglate Journey
        </motion.h1>
        {/* New enriched statement */}
        <motion.p
          className="text-2xl md:text-3xl font-playfair-display text-[#ffd9b9] text-center mb-12 italic"
          variants={itemVariants}
        >
          Crafted with Care, Rooted in Tradition, Tastes Like a Dream.
        </motion.p>

        {/* Section 1: The Birth of Jaglate */}
        <motion.section
          className="mb-16 flex flex-col md:flex-row items-center gap-10 bg-white p-8 rounded-2xl shadow-xl border border-[#EBDDB6]"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.4 }}
        >
          <motion.div className="md:w-1/2" variants={itemVariants}>
            <h2 className="text-3xl font-playfair-display text-[#3e2723] mb-4">
              A Sweet Vision, Rooted in Tradition
            </h2>
            <p className="text-lg leading-relaxed text-gray-800">
              Jaglate was born from a simple yet profound vision: to craft healthy, organic sweets without compromising on flavor. Our journey began by replacing refined sugar with nature's sweet gift—jaggery.
            </p>
            <p className="text-lg leading-relaxed text-gray-800 mt-4">
              This belief, deeply rooted in Indian tradition, allows us to create chocolate that is not just a treat, but a wholesome and authentic delight.
            </p>
          </motion.div>
          <motion.div
            className="md:w-1/2 flex justify-center items-center relative"
            variants={itemVariants}
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <img
              src={storyimage}// Placeholder for jaggery/traditional sweet image
              alt="Jaggery Blocks"
              className="w-full h-[560px] max-w-sm rounded-lg shadow-lg rotate-3 hover:rotate-0 transition-transform duration-300"
            />
            <motion.div
              className="absolute -top-6 -right-6 w-24 h-24 bg-[#FFD700] rounded-full mix-blend-multiply opacity-30"
              animate={{ rotate: 360, scale: [1, 1.1, 1] }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            ></motion.div>
          </motion.div>
        </motion.section>

        {/* Section 2: The Bean-to-Disc Commitment */}
        <motion.section
          className="mb-16 flex flex-col-reverse md:flex-row items-center gap-10 bg-white p-8 rounded-2xl shadow-xl border border-[#EBDDB6]"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.4 }}
        >
          <motion.div
            className="md:w-1/2 flex justify-center items-center relative"
            variants={itemVariants}
            initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <img
              src={storyimagetwo} // Image showing cocoa beans to chocolate
              alt="Bean to Disc Process Illustration"
              className="w-full max-w-sm rounded-lg shadow-lg -rotate-3 hover:rotate-0 transition-transform duration-300"
            />
            <motion.div
              className="absolute -bottom-6 -left-6 w-28 h-28 bg-[#A0522D] rounded-full mix-blend-multiply opacity-20"
              animate={{ x: [0, 15, 0], y: [0, -15, 0] }}
              transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
            ></motion.div>
          </motion.div>
          <motion.div className="md:w-1/2" variants={itemVariants}>
            <h2 className="text-3xl font-playfair-display text-[#3e2723] mb-4">
              Our Unwavering Bean To Disc Promise
            </h2>
            <p className="text-lg leading-relaxed text-gray-800">
              We take immense pride in controlling every step of the chocolate-making process. From meticulously sourcing the finest cocoa beans to carefully blending them with jaggery, our "Bean To Disc" approach ensures unparalleled quality.
            </p>
            <p className="text-lg leading-relaxed text-gray-800 mt-4">
              We partner directly with ethical, sustainable farms, guaranteeing that every Jaglate chocolate is crafted with premium ingredients and fair trade practices. Each disc is a testament to artisanal care.
            </p>
          </motion.div>
        </motion.section>

        {/* Section 3: The Indian Cocoa Advantage */}
        <motion.section
          className="mb-16 bg-white p-8 rounded-2xl shadow-xl border border-[#EBDDB6]"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.h2
            className="text-3xl font-playfair-display text-[#3e2723] mb-6 text-center"
            variants={itemVariants}
          >
            The Indian-Origin Cocoa Advantage
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            <motion.div className="flex flex-col items-center text-center p-4" variants={itemVariants}>
              <motion.div
                className="w-24 h-24 bg-[#FFD700] rounded-full flex items-center justify-center mb-4 text-4xl text-[#A0522D] font-bold"
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ type: "spring", stiffness: 200, damping: 10 }}
              >
                🌿
              </motion.div>
              <h3 className="text-xl font-semibold text-[#5A2E0A] mb-2">Distinct Flavor Profile</h3>
              <p className="text-gray-800">
                Grown in diverse Indian climates, our cocoa boasts a unique, earthy flavor that sets our chocolates apart from the rest.
              </p>
            </motion.div>
            <motion.div className="flex flex-col items-center text-center p-4" variants={itemVariants}>
              <motion.div
                className="w-24 h-24 bg-[#8B4513] rounded-full flex items-center justify-center mb-4 text-4xl text-white font-bold"
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ type: "spring", stiffness: 200, damping: 10, delay: 0.1 }}
              >
                🌱
              </motion.div>
              <h3 className="text-xl font-semibold text-[#5A2E0A] mb-2">Sustainable & Ethical</h3>
              <p className="text-gray-800">
                We support small-scale farmers who use eco-friendly practices, promoting a healthier planet and a responsible supply chain.
              </p>
            </motion.div>
            <motion.div className="flex flex-col items-center text-center p-4" variants={itemVariants}>
              <motion.div
                className="w-24 h-24 bg-[#A0522D] rounded-full flex items-center justify-center mb-4 text-4xl text-[#FFD700] font-bold"
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ type: "spring", stiffness: 200, damping: 10, delay: 0.2 }}
              >
                ✨
              </motion.div>
              <h3 className="text-xl font-semibold text-[#5A2E0A] mb-2">Artisanal Quality</h3>
              <p className="text-gray-800">
                Our cocoa is renowned for its superior fermentation and drying, a direct result of the artisanal care taken by our farming partners.
              </p>
            </motion.div>
          </div>
        </motion.section>

        {/* Section 4: Our Philosophy */}
        <motion.section
          className="bg-[#EBDDB6] p-8 rounded-2xl shadow-xl text-center border border-[#A0522D]"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.h2
            className="text-4xl font-luckiest-guy text-[#3e2723] mb-6"
            variants={itemVariants}
          >
            A Philosophy of Purity and Passion
          </motion.h2>
          <motion.p
            className="text-xl leading-relaxed text-gray-800 mb-8"
            variants={itemVariants}
          >
            At Jaglate, our commitment to purity, quality, and craftsmanship is unwavering. We're dedicated to blending traditional ingredients with modern tastes, creating a chocolate experience that is free from artificial additives.
          </motion.p>
          <motion.p
            className="text-2xl leading-relaxed text-[#5A2E0A] font-semibold"
            variants={itemVariants}
          >
            Join us in savoring chocolate as it's meant to be—pure, unrefined, and simply delicious.
          </motion.p>
        </motion.section>
      </div>
    </motion.div>
  );
};

export default OurStoryPage;