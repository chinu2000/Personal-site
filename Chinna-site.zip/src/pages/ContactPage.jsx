import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Button from '../components/ui/button';

const sectionVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: "easeOut",
      when: "beforeChildren",
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Thank you for your message! We will get back to you soon.');
    setFormData({ name: '', email: '', message: '' }); // Clear form
  };

  return (
    <motion.div
      className="bg-gradient-to-br from-[#A0522D] to-[#5A2E0A] py-16 px-6 min-h-[80vh] flex items-center justify-center"
      variants={sectionVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="container mx-auto max-w-4xl bg-white p-8 md:p-12 rounded-3xl shadow-2xl border border-[#EBDDB6] flex flex-col lg:flex-row gap-12">
        {/* Contact Info */}
        <motion.div className="lg:w-1/2 text-center lg:text-left" variants={itemVariants}>
          <h1 className="text-5xl md:text-6xl font-luckiest-guy text-[#A0522D] mb-6 drop-shadow-md">
            Get in Touch
          </h1>
          <p className="text-xl text-gray-700 mb-8 leading-relaxed">
            We'd love to hear from you! Whether you have a question about our chocolates, feedback, or just want to say hello, feel free to reach out.
          </p>
          <div className="space-y-6 text-lg text-gray-800">
            <motion.div variants={itemVariants} className="flex items-center gap-4 justify-center lg:justify-start">
              <span className="text-3xl text-[#FFD700]">📍</span>
              <div>
                <h3 className="font-semibold text-[#5A2E0A]">Our Address:</h3>
                <p>Eatel Industry Shed No. 102A, SIDCO Industrial Estate, Kappalur, Madurai - 625008, Tamilnadu, India.</p>
              </div>
            </motion.div>
            <motion.div variants={itemVariants} className="flex items-center gap-4 justify-center lg:justify-start">
              <span className="text-3xl text-[#FFD700]">📧</span>
              <div>
                <h3 className="font-semibold text-[#5A2E0A]">Email Us:</h3>
                <p><a href="mailto:info@jaglate.com" className="text-[#A0522D] hover:underline">info@jaglate.com</a></p>
              </div>
            </motion.div>
            <motion.div variants={itemVariants} className="flex items-center gap-4 justify-center lg:justify-start">
              <span className="text-3xl text-[#FFD700]">📞</span>
              <div>
                <h3 className="font-semibold text-[#5A2E0A]">Call Us:</h3>
                <p><a href="tel:+919876543210" className="text-[#A0522D] hover:underline">+91 98765 43210</a> (Placeholder)</p>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Contact Form */}
        <motion.div className="lg:w-1/2" variants={itemVariants}>
          <h2 className="text-4xl font-playfair-display text-[#3e2723] mb-8 text-center lg:text-left">
            Send us a Message
          </h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <motion.div variants={itemVariants}>
              <label htmlFor="name" className="block text-lg font-semibold text-[#5A2E0A] mb-2">Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FFD700] focus:border-transparent transition duration-200 bg-gray-50"
                placeholder="Your Name"
                required
              />
            </motion.div>
            <motion.div variants={itemVariants}>
              <label htmlFor="email" className="block text-lg font-semibold text-[#5A2E0A] mb-2">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FFD700] focus:border-transparent transition duration-200 bg-gray-50"
                placeholder="you@example.com"
                required
              />
            </motion.div>
            <motion.div variants={itemVariants}>
              <label htmlFor="message" className="block text-lg font-semibold text-[#5A2E0A] mb-2">Message</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows="5"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FFD700] focus:border-transparent transition duration-200 bg-gray-50"
                placeholder="Tell us what's on your mind..."
                required
              ></textarea>
            </motion.div>
            <motion.div variants={itemVariants}>
              <Button type="submit" className="w-full">Send Message</Button>
            </motion.div>
          </form>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default ContactPage;