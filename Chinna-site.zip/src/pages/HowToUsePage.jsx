import React from 'react';
import { motion, useScroll, useSpring } from 'framer-motion';

import htuimage1 from '../assets/webimage/first_image.png';
import htuimage2 from '../assets/webimage/second_image.png';
import htuimage3 from '../assets/webimage/third_image.png';
import htuimage4 from '../assets/webimage/fourth_image.png';
import htuimage5 from '../assets/webimage/wishimage.png';

const sectionVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: "easeOut",
      when: "beforeChildren",
      staggerChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const HowToUsePage = () => {
  const steps = [
    {
      id: 1,
      title: "Select Your Sweet Canvas",
      description: "Your personalized gifting journey begins with choosing the perfect Jaglate chocolate bar. Each bar, a testament to pure jaggery and rich Indian cocoa, is ready to carry your heartfelt message. Consider their favorite flavor! Milk, dark, or something nutty?",
      image: htuimage1,
      alt: "Select Jaglate Chocolate",
      animationSuggestion: "A subtle shimmer or glow around the chocolate bars.",
    },
    {
      id: 2,
      title: "Unwrap the Secret & Type Your Heart Out!",
      description: "Carefully unwrap your Jaglate bar to reveal a unique QR code area. With a quick scan using your smartphone, you'll be taken to our secure message portal. Type your personalized message, a special wish, or pick from our delightful templates. Watch your words come alive, digitally sealed within the chocolate's embrace.",
      image: htuimage2,
      alt: "Unwrap and Scan QR",
      animationSuggestion: "QR code expanding or glowing when scanned.",
    },
    {
      id: 3,
      title: "Seal Your Sweet Secret",
      description: "Once your message is perfected, simply print the generated QR code. Our packaging is cleverly designed with a dedicated slot, allowing you to seamlessly place the printed QR code back into the wrapper. It’s a perfect fit, keeping your sweet surprise hidden until the moment of delight.",
      image: htuimage3,
      alt: "Place QR in Wrapper",
      animationSuggestion: "Wrapper closing or QR code slot 'snapping' into place.",
    },
    {
      id: 4,
      title: "Present Your Thoughtful Treat",
      description: "With your message perfectly embedded, your Jaglate chocolate is now a truly unique gift. Present it to your loved one and watch their eyes light up! The beautifully designed packaging, combined with the anticipation of a hidden message, elevates this from a simple chocolate to an extraordinary gesture of affection.",
      image: htuimage4,
      alt: "Gift Jaglate with Love",
      animationSuggestion: "Gift box opening or heart emojis floating around.",
    },
    {
      id: 5,
      title: "The Grand Reveal: Scan & Smile!",
      description: "This is where the magic happens! The recipient simply scans the QR code on the wrapper with their smartphone. Instantly, your heartfelt message will appear on their screen. It’s a moment of delightful surprise, a personal connection, and a sweet memory created just for them.",
      image: htuimage5,
      alt: "Scan QR and See Message",
      animationSuggestion: "Message appearing or text swirling into view.",
    },
  ];

  // For the vertical scroll progress animation
  const { scrollYProgress } = useScroll();
  const scaleY = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <motion.div
      className="bg-gradient-to-br from-[#A0522D] to-[#5A2E0A] py-16 px-6 overflow-hidden"
      variants={sectionVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="container mx-auto max-w-5xl text-center">
        <motion.h1
          className="text-5xl md:text-6xl font-luckiest-guy text-[#d6d6d6] mb-8 drop-shadow-md leading-tight"
          variants={itemVariants}
        >
          Your Message, Our Chocolate:
          <br />
          <span className="text-[#d6d6d6] md:text-7xl">The Jaglate QR Magic!</span>
        </motion.h1>

        <motion.p
          className="text-xl md:text-2xl text-white mb-12 max-w-3xl mx-auto leading-relaxed"
          variants={itemVariants}
        >
          Go beyond just gifting chocolate. With Jaglate, you're crafting an unforgettable memory. Here's how to infuse your sweetest sentiments into every bar, creating a truly unique surprise.
        </motion.p>

        {/* Timeline Steps */}
        <div className="relative flex flex-col items-center">
          {/* Vertical Line for Timeline - Now animated */}
          <motion.div
            className="absolute left-1/2 -translate-x-1/2 w-1 bg-[#EBDDB6] origin-top z-0 hidden md:block"
            style={{ scaleY }}
            initial={{ height: 0 }}
            animate={{ height: '100%' }}
            transition={{ duration: 0.1, ease: "easeOut" }}
          ></motion.div>

          {steps.map((step, index) => (
            <motion.section
              key={step.id}
              className={`relative mb-16 w-full ${index % 2 === 0 ? 'md:pr-1/2' : 'md:pl-1/2'}`}
              variants={sectionVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
            >
              <div className={`flex flex-col md:flex-row items-center gap-8 md:gap-12 bg-white p-8 rounded-2xl shadow-xl border border-[#EBDDB6] text-left w-full
                             ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>

                {/* Number Circle (always centered horizontally, but positioned for timeline on MD screens) */}
                <motion.div
                  className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-16 md:w-20 md:h-20 bg-[#FFD700] rounded-full flex items-center justify-center text-3xl md:text-4xl font-luckiest-guy text-[#A0522D] shadow-lg z-10"
                  initial={{ scale: 0, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ type: "spring", stiffness: 200, damping: 10, delay: 0.1 }}
                >
                  {step.id}
                </motion.div>

                <motion.div
                  className={`flex flex-col w-full ${index % 2 === 0 ? 'md:w-1/2 md:pr-4' : 'md:w-1/2 md:pl-4'}`}
                  variants={itemVariants}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <h2 className="text-3xl md:text-4xl font-playfair-display text-[#3e2723] mb-4 mt-12 md:mt-0">
                    {step.title}
                  </h2>
                  <p className="text-lg leading-relaxed text-gray-800">
                    {step.description}
                  </p>
                </motion.div>

                <motion.div
                  className={`md:w-1/2 flex justify-center items-center w-full mt-8 md:mt-0
                            ${index % 2 === 0 ? 'md:order-last' : 'md:order-first'}`}
                  variants={itemVariants}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                >
                  <img
                    src={step.image}
                    alt={step.alt}
                    // Adjusted max-width classes for smaller, more consistent sizing
                    className="w-full max-w-[200px] sm:max-w-[220px] md:max-w-[240px] lg:max-w-[260px] rounded-lg shadow-lg transform transition-transform duration-300 hover:scale-105"
                  />
                  {/* Placeholder for immersive chocolate animation */}
                  {/* Example: <Lottie animationData={yourAnimationData} className="absolute inset-0 w-full h-full" /> */}
                </motion.div>
              </div>
            </motion.section>
          ))}
        </div>

        {/* Conclusion / Call to Action */}
        <motion.section
          className="bg-[#3e2723] p-8 rounded-2xl shadow-xl text-white mt-16"
          variants={sectionVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.5 }}
        >
          <motion.h2
            className="text-4xl md:text-5xl font-luckiest-guy text-[#FFD700] mb-6"
            variants={itemVariants}
          >
            Ready to Send Your Sweetest Thoughts?
          </motion.h2>
          <motion.p
            className="text-xl leading-relaxed mb-8 max-w-2xl mx-auto"
            variants={itemVariants}
          >
            Jaglate offers more than just delicious jaggery chocolate; it offers a new way to connect. Start creating your personalized chocolate message today!
          </motion.p>
          <motion.a
            href="/products/all"
            className="inline-block bg-[#FFD700] text-[#3e2723] py-3 px-8 rounded-full text-lg font-bold hover:bg-[#ffe54d] transition-all duration-300 transform hover:scale-105 shadow-lg"
            variants={itemVariants}
          >
            Explore Chocolates & Start Gifting
          </motion.a>
        </motion.section>
      </div>
    </motion.div>
  );
};

export default HowToUsePage;