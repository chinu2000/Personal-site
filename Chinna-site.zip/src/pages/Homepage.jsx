import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Button from '../components/ui/button'; // Reusable button
import Homepage from '../assets/webimage/Homepage.png';

// --- ICON IMPORTS ---
// Example imports if you're using React Icons. Adjust based on your chosen library/method.
// import { FaGrinSquintTears, FaLeaf, FaSeedling, FaStar, FaHandHoldingHeart } from 'react-icons/fa';
// Or if you have custom SVG components:
// import ChocolateBarIcon from '../assets/icons/ChocolateBarIcon';
// import QRIcon from '../assets/icons/QRIcon';
// import GiftIcon from '../assets/icons/GiftIcon';
// import HeartIcon from '../assets/icons/HeartIcon';


import image1 from '../assets/webimage/first_image.png'; 
import image2 from '../assets/webimage/second_image.png'; 
import image3 from '../assets/webimage/third_image.png';
import image4 from '../assets/webimage/fourth_image.png'; 
import image5 from '../assets/webimage/wishimage.png'; 


// Updated featuredProducts to describe the QR message gifting process
const featuredProducts = [
  {
    id: 1,
    image: image1,
    title: "Step 1: Get Your Jaglate",
    description: "Start your personalized gifting journey by choosing a delicious Jaglate chocolate bar. Our premium cocoa and jaggery blend promises pure delight."
  },
  {
    id: 2,
    image: image2,
    title: "Step 2: Unwrap & Personalize",
    description: "Carefully unwrap your chocolate to reveal a special QR code area. Scan it and effortlessly type your heartfelt message or choose from our templates."
  },
  {
    id: 3,
    image: image3,
    title: "Step 3: Seal Your Sweet Secret",
    description: "Once your message is ready, simply place the printed QR code back into the designated slot on the wrapper. It's perfectly designed for a snug fit."
  },
  {
    id: 4,
    image: image4,
    title: "Step 4: Gift with Love",
    description: "Present your custom Jaglate chocolate to your loved one. The beautifully designed packaging hints at the thoughtful surprise within."
  },
  {
    id: 5,
    image: image5,
    title: "Step 5: Scan & Share Joy!",
    description: "The recipient just needs to scan the QR code with their phone to instantly reveal your personalized message. It’s a truly magical moment!"
  },
];

const sectionVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: 'easeOut',
      when: 'beforeChildren',
      staggerChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const contentVariants = {
  enter: (direction) => ({
    x: direction > 0 ? 300 : -300, // Enter from right if next, from left if previous
    opacity: 0,
    scale: 0.9
  }),
  center: {
    x: 0,
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.6,
      ease: 'easeOut'
    }
  },
  exit: (direction) => ({
    x: direction < 0 ? 300 : -300, // Exit to right if previous, to left if next
    opacity: 0,
    scale: 0.9,
    transition: {
      duration: 0.6,
      ease: 'easeIn'
    }
  }),
};

const HomePage = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState(0); // To control animation direction

  const handleNext = () => {
    setDirection(1); // Moving forward
    setCurrentStep((prevStep) => (prevStep + 1) % featuredProducts.length);
  };

  const handlePrev = () => {
    setDirection(-1); // Moving backward
    setCurrentStep((prevStep) =>
      prevStep === 0 ? featuredProducts.length - 1 : prevStep - 1
    );
  };

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <motion.section
        className="relative flex flex-col md:flex-row items-center justify-center min-h-[90vh] bg-gradient-to-br from-[#A0522D] to-[#5A2E0A] text-white p-6 md:p-12 overflow-hidden"
        variants={sectionVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="relative z-10 text-center md:text-left md:w-full lg:w-1/2 flex flex-col items-center md:items-start max-w-xl md:max-w-none">
          <motion.h1
            className="text-5xl md:text-7xl font-luckiest-guy leading-tight mb-4 text-[#FFD700] drop-shadow-lg"
            variants={itemVariants}
          >
            {/* ICON INTEGRATION POINT: Add a playful chocolate-related icon here */}
            {/* Example: <FaGrinSquintTears className="inline-block text-[#FFD700] mr-4 text-6xl md:text-7xl" /> */}
            Unwrap Pure Goodness with <br /> <span className="text-white">Jaglate Chocolates</span>
          </motion.h1>
          <motion.p className="text-xl md:text-2xl mb-8 max-w-xl" variants={itemVariants}>
            Bean to Disc: Experience the wholesome delight of Indian cocoa perfectly blended with natural jaggery.
          </motion.p>
          <motion.div variants={itemVariants}>
            <Link to="/products/all">
              <Button variant="primary">Explore Our Range</Button>
            </Link>
          </motion.div>
        </div>
        <motion.div
          className="relative mt-8 md:mt-0 md:w-full lg:w-1/2 flex justify-center items-center"
          initial={{ opacity: 0, x: 100, rotate: -15 }}
          animate={{ opacity: 1, x: 0, rotate: 0 }}
          transition={{ duration: 1.2, delay: 0.4, type: 'spring', stiffness: 80 }}
        >
          <img
            src={Homepage}
            alt="Jaglate Jaggery Chocolate Bar"
            className="w-4/5 max-w-md lg:max-w-xl drop-shadow-2xl hover:scale-105 transition-transform duration-500 ease-out"
          />
          {/* Animated decorative elements */}
          <motion.div
            className="absolute -top-10 -left-10 w-32 h-32 bg-[#FFD700] rounded-full mix-blend-screen opacity-30 hidden md:block" // Hidden on small screens
            animate={{ y: [0, -20, 0], rotate: [0, 10, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          ></motion.div>
          <motion.div
            className="absolute -bottom-10 -right-10 w-40 h-40 bg-[#A0522D] rounded-full mix-blend-screen opacity-20 hidden md:block" // Hidden on small screens
            animate={{ x: [0, 20, 0], rotate: [0, -15, 0] }}
            transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
          ></motion.div>
        </motion.div>
      </motion.section>

      ---

      {/* Unwrap Creativity Section - Personalized Gifting Journey */}
      <motion.section
        className="py-16 md:py-20 bg-gradient-to-br from-[#A0522D] to-[#5A2E0A] text-white text-center overflow-hidden"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        variants={sectionVariants}
      >
        <motion.h2
          className="text-4xl md:text-5xl font-playfair-display text-[#FFD700] mb-8 md:mb-12 relative inline-block after:content-[''] after:absolute after:w-full after:h-1 after:bg-[#FFD700] after:bottom-0 after:left-0 after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:duration-300 px-4"
          variants={itemVariants}
        >
          Gift with a Personal Touch ❤
        </motion.h2>

        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-12">
            {/* Text Content for current step */}
            <motion.div
              key={currentStep} // Key for re-rendering and animation
              className="md:w-1/2 text-left p-6 bg-white bg-opacity-10 rounded-xl shadow-lg backdrop-blur-sm w-full"
              variants={contentVariants}
              initial="enter"
              animate="center"
              exit="exit"
              custom={direction} // Pass direction for animation
            >
              <h3 className="text-3xl md:text-4xl font-semibold mb-4 text-[#FFD700]">
                {featuredProducts[currentStep].title}
              </h3>
              <p className="text-lg md:text-xl leading-relaxed">
                {featuredProducts[currentStep].description}
              </p>
            </motion.div>

            {/* Image for current step */}
            <motion.div
              key={currentStep + "_image"} // Unique key for image transition
              className="md:w-1/2 flex justify-center items-center w-full"
              variants={contentVariants}
              initial="enter"
              animate="center"
              exit="exit"
              custom={direction} // Pass direction for animation
            >
              <div className="w-[280px] h-[350px] sm:w-[320px] sm:h-[400px] lg:w-[360px] lg:h-[450px] flex-shrink-0 rounded-2xl overflow-hidden bg-white shadow-xl transform hover:scale-105 transition-transform duration-500">
                <img
                  src={featuredProducts[currentStep].image}
                  alt={featuredProducts[currentStep].title}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>
          </div>

          {/* Navigation Controls */}
          <div className="flex justify-center items-center gap-4 mt-8 md:mt-12">
            <Button
              variant="secondary"
              onClick={handlePrev}
              disabled={currentStep === 0}
              className="px-5 py-2 md:px-6 md:py-3 text-base md:text-lg rounded-full shadow-md transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </Button>
            <div className="text-lg md:text-xl">
              {currentStep + 1} / {featuredProducts.length}
            </div>
            <Button
              variant="secondary"
              onClick={handleNext}
              disabled={currentStep === featuredProducts.length - 1}
              className="px-5 py-2 md:px-6 md:py-3 text-base md:text-lg rounded-full shadow-md transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </Button>
          </div>

          {/* Progress Indicators (Dots) */}
          <div className="flex justify-center gap-3 mt-4">
            {featuredProducts.map((_, index) => (
              <span
                key={index}
                className={`w-3 h-3 rounded-full cursor-pointer transition-colors duration-300 ${
                  index === currentStep ? 'bg-[#FFD700]' : 'bg-gray-400'
                }`}
                onClick={() => setCurrentStep(index)}
              ></span>
            ))}
          </div>
        </div>
      </motion.section>

      ---

      {/* Why Jaglate Section - Redesigned with Icon Placeholders */}
      <motion.section
        className="py-16 md:py-20 bg-gradient-to-br from-[#A0522D] to-[#5A2E0A] px-4"
        variants={sectionVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <div className="container mx-auto text-center">
          <motion.h2
            className="text-4xl md:text-5xl font-playfair-display mb-12 relative inline-block after:content-[''] after:absolute after:w-full after:h-1 after:bg-[#A0522D] after:bottom-0 after:left-0 after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:duration-300 px-4"
            variants={itemVariants}
          >
            Why Choose Jaglate: The Pure Difference
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 lg:gap-16 mt-8">
            {/* Benefit 1: Pure Jaggery Sweetness */}
            <motion.div className="p-6  bg-white rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300" variants={itemVariants}>
              {/* ICON INTEGRATION POINT */}
              {/* Example: <FaSeedling className="text-6xl text-[#A0522D] mb-4 mx-auto" /> */}
              <div className="text-6xl text-[#A0522D] mb-4 mx-auto">🌱</div> {/* Placeholder emoji for jaggery/natural */}
              <h3 className="text-2xl font-semibold mb-3 text-[#A0522D]">Pure Jaggery Sweetness</h3>
              <p className="text-lg leading-relaxed text-[#000000]">
                We replace refined sugar entirely with 'natural jaggery', offering a healthier, unrefined sweetness with distinct caramel notes. Taste the difference in every bite!
              </p>
            </motion.div>

            {/* Benefit 2: Authentic Indian Cocoa */}
            <motion.div className="p-6 bg-white rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300" variants={itemVariants}>
              {/* ICON INTEGRATION POINT */}
              {/* Example: <FaLeaf className="text-6xl text-[#A0522D] mb-4 mx-auto" /> */}
              <div className="text-6xl text-[#A0522D] mb-4 mx-auto">🍫</div> {/* Placeholder emoji for chocolate/cocoa */}
              <h3 className="text-2xl font-semibold mb-3 text-[#A0522D]">Authentic Indian Cocoa</h3>
              <p className="text-lg leading-relaxed text-[#000000]">
                Our cocoa beans are sourced directly from sustainable farms in India, ensuring a unique, rich flavor profile and supporting local communities.
              </p>
            </motion.div>

            {/* Benefit 3: Bean to Disc Craftsmanship */}
            <motion.div className="p-6 bg-white rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300" variants={itemVariants}>
              {/* ICON INTEGRATION POINT */}
              {/* Example: <FaStar className="text-6xl text-[#A0522D] mb-4 mx-auto" /> */}
              <div className="text-6xl text-[#A0522D] mb-4 mx-auto">✨</div> {/* Placeholder emoji for craftsmanship/quality */}
              <h3 className="text-2xl font-semibold mb-3 text-[#A0522D]">Bean to Disc Craftsmanship</h3>
              <p className="text-lg leading-relaxed text-[#000000]">
                From roasting the finest beans to crafting perfect discs, our meticulous process guarantees superior quality and an unforgettable chocolate experience.
              </p>
            </motion.div>
          </div>

          <motion.div variants={itemVariants} className="mt-12">
            <Link to="/our-story">
              <Button variant="primary">Discover Our Commitment</Button>
            </Link>
          </motion.div>
        </div>
      </motion.section>

      ---

      {/* Call to Action */}
      <motion.section
        className="py-16 md:py-20 bg-[#3e2723] text-white text-center px-6"
        variants={sectionVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
      >
        <motion.h2
          className="text-4xl md:text-5xl font-luckiest-guy text-[#FFD700] mb-8"
          variants={itemVariants}
        >
          Ready for a Healthier Indulgence?
        </motion.h2>
        <motion.p
          className="text-xl md:text-2xl mb-10 max-w-2xl mx-auto"
          variants={itemVariants}
        >
          Join the Jaglate family and experience chocolate reimagined – pure, unrefined, and simply delicious.
        </motion.p>
        <motion.div variants={itemVariants}>
          <Link to="/contact">
            <Button variant="primary">Get in Touch</Button>
          </Link>
        </motion.div>
      </motion.section>
    </div>
  );
};

export default HomePage;