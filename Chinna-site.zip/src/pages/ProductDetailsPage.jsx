import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, useMotionValue, animate } from 'framer-motion';

// --- Animation Variants ---
const containerVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: "easeOut",
      when: "beforeChildren",
      staggerChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.6,
      ease: "easeOut",
    },
  },
};

// --- Button Component (Assuming this is in a separate file, but included here for completeness) ---
const Button = ({ children, onClick, className = "", disabled = false }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${className} ${
      disabled ? 'opacity-50 cursor-not-allowed' : ''
    }`}
  >
    {children}
  </button>
);

// --- Main ProductDetailsPage Component ---
const ProductDetailsPage = () => {
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [windowWidth, setWindowWidth] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth : 1024
  );
  const carouselRef = useRef(null); // Ref to the container holding the carousel track
  const carouselTrackRef = useRef(null); // Ref to the motion.div that actually moves

  // --- Data for Process Steps and Nutritional Info ---
  const processSteps = [
    {
      title: "Getting Cacao Beans Straight from the Source",
      description: "Chocolate makers handpick top-notch beans straight from sustainable farms or co-ops, promoting transparency and fair trade. By focusing on where the beans come from, each chocolate bar gets its own delicious twist, showing off the unique flavors of the cacao-growing area.",
      icon: '🌿',
    },
    {
      title: "Roasting in Small Batches",
      description: "The natural flavors of the beans are preserved as they are roasted very lightly. Each batch stands alone as the times and temperatures for roasting are varied to suit the particular variety of the cacao.",
      icon: '🔥',
    },
    {
      title: "Cracking and Separation",
      description: "Subsequent to the process of roasting, the beans are cracked to achieve the separation of the nibs (which are the consumable portion) from the husks. The nibs then undergo a transformation into chocolate.",
      icon: '⚙️',
    },
    {
      title: "Grinding and Refining",
      description: "The cacao nibs are stone-ground into a smooth paste, called chocolate liquor. Depending on the recipe, other ingredients like milk powder, jaggery, vanilla extract and soya lecithin are slowly added during this process.",
      icon: '🥣',
    },
    {
      title: "Conching for Texture and Flavor Development",
      description: "The chocolate undergoes additional refining through a technique called conching, where it is continuously mixed to enhance its smoothness and develop intricate flavors that evolve over the course of several hours.",
      icon: '🌀',
    },
    {
      title: "Tempering and Molding",
      description: "The chocolate undergoes tempering to stabilize the cocoa butter, resulting in a shiny appearance and a satisfying crack when broken. Once tempered, it is poured into molds and left to cool and solidify.",
      icon: '🍫',
    },
    {
      title: "Handcrafted Quality",
      description: "Bean-to-bar chocolate is well-known for its high-quality artisanal craftsmanship. The whole process shows dedication, excitement, and appreciation for the ingredients, giving customers a genuine chocolate experience.",
      icon: '✋',
    },
  ];

  const nutritionalInfo = [
    { label: "Energy", value: "547 Kcal" },
    { label: "Total Carbohydrate", value: "58.6%" },
    { label: "Cholesterol", value: "2.0 mg" },
    { label: "Sugar", value: "48%" },
    { label: "Added Sugar", value: "13.4%" },
    { label: "Total Fat", value: "31.7%" },
    { label: "Protein", value: "6.9%" },
    { label: "Calcium", value: "27.5mg" },
    { label: "Magnesium", value: "15.3mg" },
    { label: "Potassium", value: "903.7mg" },
    { label: "Sodium", value: "139.7mg" },
  ];

  // --- Framer Motion Value for Carousel Translation ---
  const x = useMotionValue(0);

  // --- Responsive Card Dimensions Calculation ---
  const getCardDimensions = useCallback(() => {
    // These values must match the Tailwind CSS classes applied to the cards
    // The 'gap' is HALF of the total horizontal space given by mx-5 (margin-left/right of 20px each)
    if (windowWidth >= 1280) return { width: 400, gap: 40 }; // lg:w-[400px] + mx-5 -> effective width 440 (400 + 2*20)
    if (windowWidth >= 1024) return { width: 360, gap: 40 }; // md:w-[360px] + mx-5 -> effective width 400
    if (windowWidth >= 768) return { width: 320, gap: 40 };  // sm:w-[320px] + mx-5 -> effective width 360
    return { width: 280, gap: 40 }; // w-[280px] + mx-5 -> effective width 320 (280 + 2*20)
  }, [windowWidth]);

  // --- Calculate Carousel Position for Centering ---
  const calculateCarouselPosition = useCallback(() => {
    if (!carouselRef.current) return 0;

    const { width: cardWidth, gap } = getCardDimensions();
    const carouselContainerWidth = carouselRef.current.offsetWidth; // Width of the visible window
    const cardWidthWithGap = cardWidth + gap; // This is the total space each card takes up including its right margin

    // Target position for the carousel track to center the current card
    // The track starts at x=0, and we want to shift it so currentCardIndex is centered
    // We also account for the centering of the FIRST card in the visible window
    return -(currentCardIndex * cardWidthWithGap) + (carouselContainerWidth / 2) - (cardWidth / 2);

  }, [currentCardIndex, windowWidth, getCardDimensions]);

  // --- Update Carousel Position with Animation ---
  const updateCarouselPosition = useCallback(() => {
    const targetX = calculateCarouselPosition();
    animate(x, targetX, {
      type: "spring",
      stiffness: 300, // Slightly less stiff for smoother feel
      damping: 35,   // More damping
      mass: 0.8,    // Lighter mass for quicker response
    });
  }, [x, calculateCarouselPosition]);

  // --- Event Listeners for Resize ---
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    const debouncedResize = debounce(handleResize, 100);
    window.addEventListener('resize', debouncedResize);

    return () => window.removeEventListener('resize', debouncedResize);
  }, []);

  // --- Trigger Position Update when Dependencies Change ---
  useEffect(() => {
    // Adding a small delay to ensure refs are measured correctly after render/resize
    const timer = setTimeout(updateCarouselPosition, 50);
    return () => clearTimeout(timer);
  }, [currentCardIndex, updateCarouselPosition]); // Only re-run when index changes or updateCarouselPosition callback changes

  // --- Navigation Handlers (Ensuring Loop) ---
  const handleNext = () => {
    setCurrentCardIndex((prev) => (prev + 1) % processSteps.length);
  };

  const handlePrev = () => {
    setCurrentCardIndex((prev) => (prev - 1 + processSteps.length) % processSteps.length);
  };


  // --- Touch/Swipe Handling ---
  const [dragStart, setDragStart] = useState(0);

  const handleDragStart = useCallback((event, info) => {
    setDragStart(info.point.x);
  }, []);

  const handleDragEnd = useCallback((event, info) => {
    const dragDistance = info.point.x - dragStart;
    const threshold = 50; // Minimum drag distance to trigger a slide

    if (Math.abs(dragDistance) > threshold) {
      if (dragDistance > 0) { // Swiped right
        handlePrev();
      } else { // Swiped left
        handleNext();
      }
    } else {
      // If drag was not enough to change card, snap back to current
      updateCarouselPosition();
    }
  }, [dragStart, handlePrev, handleNext, updateCarouselPosition]);

  // --- Get Card Visual Properties (Scale, Opacity, Blur, Z-Index) ---
  const getCardVisuals = useCallback((index) => {
    const offset = getCardOffset(index, currentCardIndex, processSteps.length);

    if (windowWidth < 768) { // Mobile: One clear card, others mostly hidden
      return {
        scale: offset === 0 ? 1 : 0.8,
        opacity: offset === 0 ? 1 : 0.05, // Make off-screen cards barely visible
        blur: offset === 0 ? 0 : 10,
        zIndex: offset === 0 ? 10 : 1,
      };
    }

    // Desktop: Progressive focus/blur
    switch (Math.abs(offset)) {
      case 0: return { scale: 1, opacity: 1, blur: 0, zIndex: 10 };
      case 1: return { scale: 0.9, opacity: 0.7, blur: 2, zIndex: 5 };
      case 2: return { scale: 0.8, opacity: 0.4, blur: 4, zIndex: 3 };
      default: return { scale: 0.7, opacity: 0.1, blur: 6, zIndex: 1 };
    }

  }, [currentCardIndex, windowWidth, processSteps.length]);

  return (
    <motion.div
      className="bg-gradient-to-br from-[#A0522D] to-[#5A2E0A] min-h-screen pb-16" // Added pb-16 for bottom spacing
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        {/* --- Hero Section --- */}
        <motion.div className="text-center mb-12 sm:mb-16 lg:mb-20" variants={itemVariants}>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-['Luckiest_Guy'] text-[#d6d6d6] mb-4 sm:mb-6 lg:mb-8 leading-tight drop-shadow-md">
            Our Story: Crafting Jaglate Magic
          </h1>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-white max-w-4xl mx-auto leading-relaxed px-4 font-['Playfair_Display']">
            At Jaglate, we believe in the magic of pure ingredients and a passionate process. Discover what makes our bean-to-bar jaggery chocolate truly special.
          </p>
        </motion.div>

        {/* --- Nutritional Information --- */}
        <motion.section
          className="bg-white/80 backdrop-blur-sm p-4 sm:p-6 lg:p-8 rounded-2xl shadow-xl border border-[#EBDDB6] mb-12 sm:mb-16 lg:mb-20 max-w-4xl mx-auto"
          variants={itemVariants}
        >
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-['Playfair_Display'] text-[#5A2E0A] mb-4 sm:mb-6 text-center font-bold">
            Nutritional Information (per 100g)
          </h2>
          <div className="overflow-x-auto -mx-2 sm:mx-0">
            <table className="min-w-full bg-white rounded-lg overflow-hidden">
              <thead className="bg-[#FFD700] text-[#3e2723]">
                <tr>
                  <th className="py-2 sm:py-3 px-3 sm:px-4 text-center text-sm sm:text-base font-semibold">Nutrient</th>
                  <th className="py-2 sm:py-3 px-3 sm:px-4 text-center text-sm sm:text-base font-semibold">Value</th>
                </tr>
              </thead>
              <tbody>
                {nutritionalInfo.map((item, index) => (
                  <tr key={index} className={`${index % 2 === 0 ? 'bg-[#fcfbf8]' : 'bg-white'} border-b border-[#EBDDB6]`}>
                    <td className="py-2 sm:py-3 px-3 sm:px-4 text-gray-800 text-sm sm:text-base font-['Playfair_Display']">{item.label}</td>
                    <td className="py-2 sm:py-3 px-3 sm:px-4 text-gray-800 text-sm sm:text-base font-medium font-['Playfair_Display']">{item.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs sm:text-sm text-gray-600 mt-3 sm:mt-4 italic text-center font-['Playfair_Display']">
            *Approximate values based on our standard milk chocolate recipe. May vary slightly.
          </p>
        </motion.section>

        {/* --- Process Steps Carousel --- */}
        <motion.section variants={itemVariants}>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-['Luckiest_Guy'] text-[#fff9f6] mb-8 sm:mb-12 text-center drop-shadow-md">
            What Sets Our Chocolate Apart
          </h2>

          <div className="relative max-w-7xl mx-auto">
            {/* Carousel Container (Viewport) */}
            <div ref={carouselRef} className="overflow-hidden py-4 sm:py-6 lg:py-8">
              {/* Carousel Track */}
              <motion.div
                ref={carouselTrackRef}
                className="flex items-stretch" // items-stretch ensures all cards have same height if content varies
                style={{ x }}
                // Enable dragging for touch/swipe
                drag="x"
                // Drag constraints are not needed as we handle position with `x` and `animate`
                // dragConstraints={{ left: 0, right: 0 }} // Remove this line
                dragElastic={0.5} // How much the carousel can be "pulled" past its bounds
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
              >
                {processSteps.map((step, index) => {
                  const { width: cardWidth, gap } = getCardDimensions();
                  const { scale, opacity, blur, zIndex } = getCardVisuals(index);

                  return (
                    <motion.div
                      key={index}
                      className="flex-shrink-0 bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg border border-[#EBDDB6] p-4 sm:p-6 lg:p-8 cursor-pointer transform-gpu flex flex-col" // Added flex flex-col for internal layout
                      style={{
                        width: cardWidth,
                        marginLeft: index === 0 ? 0 : gap, // Apply margin only to the left of subsequent cards
                        scale,
                        opacity,
                        filter: `blur(${blur}px)`, // Apply blur directly
                        zIndex,
                        minHeight: windowWidth < 640 ? '400px' : windowWidth < 1024 ? '450px' : '500px', // Responsive min-height
                      }}
                      onClick={() => setCurrentCardIndex(index)}
                      whileHover={{ scale: scale * 1.02, transition: { duration: 0.1 } }} // Subtle hover effect
                      transition={{ type: "spring", stiffness: 300, damping: 30 }} // Smooth transition for individual card properties
                    >
                      <div className="flex flex-col items-center text-center h-full">
                        <div className="text-4xl sm:text-5xl lg:text-6xl mb-3 sm:mb-4 p-3 sm:p-4 bg-[#FFD700] rounded-full shadow-md">
                          {step.icon}
                        </div>
                        <h3 className="text-lg sm:text-xl lg:text-2xl font-['Playfair_Display'] text-[#5A2E0A] mb-3 sm:mb-4 leading-tight font-bold">
                          {step.title}
                        </h3>
                        <p className="text-sm sm:text-base lg:text-lg text-gray-800 leading-relaxed flex-1 font-['Playfair_Display']">
                          {step.description}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </motion.div>
            </div>

            {/* Navigation Arrows (Desktop Only) */}
            <Button
              onClick={handlePrev} // Correctly assigned to previous
              className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 bg-[#A0522D] hover:bg-[#8B4513] text-white p-2 sm:p-3 rounded-full shadow-lg z-20 hidden md:block"
            >
              <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </Button>

            <Button
              onClick={handleNext} // Correctly assigned to next
              className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 bg-[#A0522D] hover:bg-[#8B4513] text-white p-2 sm:p-3 rounded-full shadow-lg z-20 hidden md:block"
            >
              <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Button>

            {/* Dots Navigation */}
            {/* <div className="flex justify-center gap-2 sm:gap-3 mt-6 sm:mt-8">
              {processSteps.map((_, index) => (
                <button
                  key={index}
                  className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full transition-all duration-300 ${
                    index === currentCardIndex
                      ? 'bg-[#A0522D] scale-125'
                      : 'bg-gray-400 hover:bg-gray-500'
                  }`}
                  onClick={() => setCurrentCardIndex(index)}
                />
              ))}
            </div> */}

            {/* Mobile Navigation Buttons (visible only on small screens) */}
            <div className="flex justify-center gap-4 mt-6 md:hidden">
              <Button
                onClick={handlePrev}
                className="bg-[#A0522D] hover:bg-[#8B4513] text-white px-4 py-2 rounded-full shadow-lg"
              >
                <svg className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                  
              </Button>
              <Button
                onClick={handleNext}
                className="bg-[#A0522D] hover:bg-[#8B4513] text-white px-4 py-2 rounded-full shadow-lg"
              >
                 <svg className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
              </Button>
            </div>
          </div>
        </motion.section>

        {/* --- Call to Action --- */}
        {/* <motion.div
          className="mt-16 text-center"
          variants={itemVariants}
        > */}
          {/* Note: If ProductDetailsPage is now the "Our Story" page, you might adjust this navigation. */}
          {/* For example, navigate to a separate /products page if it exists. */}
          {/* <Button
            onClick={() => console.log('Navigate to products page')} // Replace with actual navigation
            className="bg-[#A0522D] hover:bg-[#8B4513] text-white text-lg sm:text-xl px-6 py-3 rounded-full shadow-lg transition-all duration-300"
          >
            Explore Our Chocolates
          </Button>
        </motion.div> */}
      </div>
    </motion.div>
  );
};

// --- Utility Functions (Keep these outside the component or in a separate utils file) ---
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Calculates the effective offset for infinite looping
function getCardOffset(index, currentIndex, totalCards) {
  let offset = index - currentIndex;
  if (offset > totalCards / 2) {
    offset -= totalCards;
  } else if (offset < -totalCards / 2) {
    offset += totalCards;
  }
  return offset;
}

export default ProductDetailsPage;