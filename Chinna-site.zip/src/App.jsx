import React, { useState }  from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/ui/Navbar';
import Footer from './components/ui/Footer';
import HomePage from './pages/Homepage';
import OurStoryPage from './pages/OurStoryPage';
import HowToUsePage from './pages/HowToUsePage';
import ProductDetailsPage from './pages/ProductDetailsPage';
import ContactPage from './pages/ContactPage';
import { AnimatePresence, motion } from 'framer-motion';
import './App.css';
import Preloader from './components/ui/Preloader'; 
import ScrollToTop from './components/ScrollToTop';

function App() {
  const [loading, setLoading] = useState(true); 
  const location = useLocation();

  // Page transition variants
  const pageVariants = {
    initial: {
      opacity: 0,
      y: 20,
    },
    in: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut",
      },
    },
    out: {
      opacity: 0,
      y: -20,
      transition: {
        duration: 0.6,
        ease: "easeIn",
      },
    },
  };

  if (loading) {
    return <Preloader finishLoading={() => setLoading(false)} />;
  }

  return (
    <div className="flex flex-col min-h-screen">
      <ScrollToTop />
      <Navbar />
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={
              <motion.div
                variants={pageVariants}
                initial="initial"
                animate="in"
                exit="out"
              >
                <HomePage />
              </motion.div>
            } />
            <Route path="/our-story" element={
              <motion.div
                variants={pageVariants}
                initial="initial"
                animate="in"
                exit="out"
              >
                <OurStoryPage />
              </motion.div>
            } />
            <Route path="/how-to-use" element={
              <motion.div
                variants={pageVariants}
                initial="initial"
                animate="in"
                exit="out"
              >
                <HowToUsePage />
              </motion.div>
            } />
            <Route path="/products/:id" element={
              <motion.div
                variants={pageVariants}
                initial="initial"
                animate="in"
                exit="out"
              >
                <ProductDetailsPage />
              </motion.div>
            } />
            <Route path="/contact" element={
              <motion.div
                variants={pageVariants}
                initial="initial"
                animate="in"
                exit="out"
              >
                <ContactPage />
              </motion.div>
            } />
          </Routes>
        </AnimatePresence>
      </main>
      <Footer />
    </div>
  );
}

export default App;