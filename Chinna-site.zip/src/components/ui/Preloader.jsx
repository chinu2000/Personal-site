import React, { useEffect } from "react";
import { motion } from "framer-motion";
import cookieImage from "../../assets/cookie.png";

const Preloader = ({ finishLoading }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      finishLoading();
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 bg-white z-[9999] flex flex-col items-center justify-center gap-8">
      <motion.img
        src={cookieImage}
        alt="Rolling Cookie"
        className="w-[280px] sm:w-[330px] md:w-[430px] lg:w-[510px] h-auto" // <-- Maintain aspect ratio
        animate={{
          x: ["-200px", "200px", "-200px"],
          rotate: [0, 360, 0],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      <motion.h1
        className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#8B4513] tracking-wide"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.8 }}
      >
        Jaglate
      </motion.h1>
    </div>
  );
};

export default Preloader;
