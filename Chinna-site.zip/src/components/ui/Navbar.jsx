import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Our Story', path: '/our-story' },
    { name: 'How To Use', path: '/how-to-use' },
    { name: 'Products', path: '/products/all' },
    { name: 'Contact Us', path: '/contact' },
  ];

  const menuVariants = {
    hidden: { opacity: 0, x: "100%" },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15,
        when: "beforeChildren",
        staggerChildren: 0.1,
      },
    },
    exit: {
      opacity: 0,
      x: "100%",
      transition: {
        ease: "easeOut",
        duration: 0.3
      }
    }
  };

  const menuItemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  const backdropVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
    exit: { opacity: 0 }
  };

  return (
    <motion.nav
      className="bg-[#A0522D] text-white p-4 shadow-lg sticky top-0 z-50"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 120, damping: 14 }}
    >
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-3xl font-['Luckiest_Guy'] text-[#FFD700] hover:text-white transition-colors duration-300">
          Jaglate
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex space-x-8">
          {navLinks.map((link) => (
            <NavLink
              key={link.name}
              to={link.path}
              className={({ isActive }) =>
                `text-lg font-bold relative group overflow-hidden py-1 font-['Playfair_Display'] ${
                  isActive ? 'text-[#FFD700]' : 'text-white hover:text-[#FFD700]'
                } transition-colors duration-300`
              }
            >
              {link.name}
              <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#FFD700] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
            </NavLink>
          ))}
        </div>

        {/* Mobile Menu Button (Hamburger/Cookie Icon) */}
        {/* Adjusted size of the button and SVG */}
        <button
          className="md:hidden text-white w-9 h-9 rounded-full bg-[#8B4513] flex items-center justify-center p-1.5 shadow-md z-50"
          onClick={toggleMenu}
          aria-label="Toggle navigation menu"
        >
          {/* Cookie/Pill-like menu icon - smaller SVG */}
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 12h16M4 6h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Mobile Menu and Backdrop */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop Overlay */}
            <motion.div
              className="fixed inset-0 bg-black bg-opacity-50 z-30"
              variants={backdropVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              onClick={toggleMenu} // Close menu when clicking backdrop
            />

            {/* Mobile Menu Content */}
            <motion.div
              className="md:hidden fixed top-0 right-0 h-screen w-2/3 max-w-xs bg-[#5A2E0A] flex flex-col items-start pt-20 px-6 space-y-8 z-40 shadow-xl"
              variants={menuVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
            >
              {/* Close button specific to the mobile menu content - smaller button and SVG */}
              <button
                className="absolute top-4 right-4 text-white w-8 h-8 rounded-full bg-[#8B4513] flex items-center justify-center p-1 shadow-md"
                onClick={toggleMenu}
                aria-label="Close navigation menu"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>

              {navLinks.map((link) => (
                <motion.div key={link.name} variants={menuItemVariants}>
                  <NavLink
                    to={link.path}
                    onClick={() => setIsOpen(false)}
                    className={({ isActive }) =>
                      `text-xl font-bold font-['Playfair_Display'] ${
                        isActive ? 'text-[#FFD700]' : 'text-white hover:text-[#FFD700]'
                      } transition-colors duration-300`
                    }
                  >
                    {link.name}
                  </NavLink>
                </motion.div>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navbar;