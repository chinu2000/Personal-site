import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const Footer = () => {
  return (
    <motion.footer
      className="bg-[#3e2723] text-white py-12 px-6"
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
    >
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-10 text-center md:text-left">
        {/* About Jaglate */}
        <div className="flex flex-col items-center md:items-start">
          <Link to="/" className="text-4xl font-luckiest-guy text-[#FFD700] mb-4 hover:text-white transition-colors duration-300">
            Jaglate
          </Link>
          <p className="text-gray-300 leading-relaxed max-w-sm">
            Crafting pure, natural jaggery chocolates. A guilt-free indulgence, rooted in tradition and quality.
          </p>
          <div className="flex space-x-4 mt-6">
            <motion.a href="https://facebook.com/jaglate" target="_blank" rel="noopener noreferrer"
              className="text-white hover:text-[#FFD700] text-2xl transition-colors duration-300"
              whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}
            >
              <i className="fab fa-facebook-f"></i> {/* Add Font Awesome or similar */}
              FB
            </motion.a>
            <motion.a href="https://instagram.com/jaglate" target="_blank" rel="noopener noreferrer"
              className="text-white hover:text-[#FFD700] text-2xl transition-colors duration-300"
              whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}
            >
              <i className="fab fa-instagram"></i>
              IG
            </motion.a>
            <motion.a href="https://twitter.com/jaglate" target="_blank" rel="noopener noreferrer"
              className="text-white hover:text-[#FFD700] text-2xl transition-colors duration-300"
              whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}
            >
              <i className="fab fa-twitter"></i>
              TW
            </motion.a>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h3 className="text-2xl font-playfair-display text-[#FFD700] mb-6 relative inline-block after:content-[''] after:absolute after:w-full after:h-0.5 after:bg-[#A0522D] after:bottom-0 after:left-0">
            Quick Links
          </h3>
          <ul className="space-y-3">
            <li><Link to="/" className="text-gray-300 hover:text-white transition-colors duration-300">Home</Link></li>
            <li><Link to="/our-story" className="text-gray-300 hover:text-white transition-colors duration-300">Our Story</Link></li>
            <li><Link to="/how-to-use" className="text-gray-300 hover:text-white transition-colors duration-300">How To Use</Link></li>
            <li><Link to="/products/all" className="text-gray-300 hover:text-white transition-colors duration-300">Products</Link></li>
            <li><Link to="/contact" className="text-gray-300 hover:text-white transition-colors duration-300">Contact Us</Link></li>
          </ul>
        </div>

        {/* Contact Info */}
        <div>
          <h3 className="text-2xl font-playfair-display text-[#FFD700] mb-6 relative inline-block after:content-[''] after:absolute after:w-full after:h-0.5 after:bg-[#A0522D] after:bottom-0 after:left-0">
            Contact Info
          </h3>
          <p className="text-gray-300 mb-2">Eatel Industry Shed No. 102A, SIDCO Industrial Estate, Kappalur, Madurai - 625008, Tamilnadu.</p>
          <p className="text-gray-300 mb-2">Email: <a href="mailto:info@jaglate.com" className="hover:underline">info@jaglate.com</a></p>
          <p className="text-gray-300">Phone: <a href="tel:+919876543210" className="hover:underline">+91 98765 43210</a></p>
        </div>
      </div>
      <div className="border-t border-gray-700 mt-10 pt-6 text-center text-gray-400">
        &copy; {new Date().getFullYear()} Jaglate. All rights reserved.
      </div>
    </motion.footer>
  );
};

export default Footer;