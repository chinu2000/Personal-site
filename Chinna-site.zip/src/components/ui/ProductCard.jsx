import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Button from './button'; // Assuming you have a reusable Button component

const ProductCard = ({ product }) => {
  return (
    <motion.div
      className="bg-white rounded-2xl p-6 text-center shadow-lg relative overflow-hidden group border-2 border-[#EBDDB6] hover:border-[#A0522D] transition-all duration-300"
      whileHover={{ scale: 1.03, rotate: 2 }} // Subtle rotation for funkiness
      transition={{ type: 'spring', stiffness: 300, damping: 10 }}
    >
      <Link to={`/products/${product.id}`} className="block">
        <div className="h-48 flex items-center justify-center mb-4 relative z-10">
          <img
            src={product.image}
            alt={product.name}
            className="max-h-full max-w-full object-contain transition-transform duration-300 group-hover:scale-110"
          />
          {/* Subtle animated background shape */}
          <motion.div
            className="absolute inset-0 bg-[#FFD700] rounded-full opacity-0 group-hover:opacity-10 transition-opacity duration-300 transform scale-0 group-hover:scale-125"
            transition={{ duration: 0.5, ease: "easeOut" }}
          ></motion.div>
        </div>
        <h3 className="text-2xl font-playfair-display text-[#3e2723] mb-2">
          {product.name}
        </h3>
        <p className="text-md text-gray-600 mb-4 h-16 overflow-hidden">
          {product.description}
        </p>
        <div className="text-3xl font-luckiest-guy text-[#A0522D] mb-4">
          ₹{product.price.toLocaleString()}
        </div>
      </Link>
      <Button onClick={() => console.log(`Added ${product.name} to cart`)}>
        Add to Cart
      </Button>
    </motion.div>
  );
};

export default ProductCard;