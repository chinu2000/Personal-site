import React from 'react';
import { motion } from 'framer-motion';

const Button = ({ children, onClick, variant = 'primary', className = '' }) => {
  const baseClasses = "py-3 px-8 rounded-full text-lg font-bold transition-all duration-300 shadow-md transform active:scale-95 flex items-center justify-center gap-2";
  let variantClasses = "";

  switch (variant) {
    case 'primary':
      variantClasses = "bg-[#FFD700] text-[#3e2723] hover:bg-[#ffe54d] hover:shadow-lg";
      break;
    case 'secondary':
      variantClasses = "bg-[#A0522D] text-white hover:bg-[#8B4513] hover:shadow-lg";
      break;
    case 'outline':
      variantClasses = "bg-transparent border-2 border-[#A0522D] text-[#A0522D] hover:bg-[#A0522D] hover:text-white";
      break;
    default:
      variantClasses = "bg-[#FFD700] text-[#3e2723] hover:bg-[#ffe54d]";
  }

  return (
    <motion.button
      className={`${baseClasses} ${variantClasses} ${className}`}
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
    >
      {children}
    </motion.button>
  );
};

export default Button;